package com.in28minutes.spring.basics.springin5steps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIn5StepsApplicationTests {

	@Test
	void contextLoads() {
	}

}
