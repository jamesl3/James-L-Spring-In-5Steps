package com.in28minutes.spring.basics.springin5steps.basic;

public interface SteeringColumn {

}
