package com.in28minutes.spring.basics.springin5steps;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.in28minutes.spring.basics.properties.SomeExternalService;

@Configuration
@ComponentScan("com.in28minutes.spring.basics.properties")
@PropertySource("classpath:app.properties")
public class SpringIn5StepsPropertiesApplication {

	
	public static void main(String[] args) {
		//No need to create a BinarySearchImpl object; Instead we tell Spring to get it for us
		//BinarySearchImpl binarySearch = new BinarySearchImpl(new QuickSortAlgorithm()); 
		//Application context
		try (AnnotationConfigApplicationContext applicationContext = new AnnotationConfigApplicationContext(
				SpringIn5StepsPropertiesApplication.class)) {

		
			SomeExternalService service = applicationContext.getBean(SomeExternalService.class);
			System.out.println(service.returnServiceUrl());
			//ComponentDAO componentDao = applicationContext.getBean(ComponentDAO.class);
		
		
		//LOGGER.info("{}", componentDao);
		
		
	}

}
}