package com.in28minutes.spring.basics.springin5steps;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.in28minutes.spring.basics.springin5steps.xml.XmlPersonDAO;

@Configuration
@ComponentScan("com.in28minutes.spring.basics.springin5steps")
public class SpringIn5StepsXmlContextApplication {

	//What are the beans? In this case, the new instance of QuickSortAlgorithm is the bean
	//What are the dependencies for each bean? In this case, the dependency of BinarySortImpl
	//is the sortAlgorithm
	//Where should Spring search for Beans?
	public static void main(String[] args) {
		//No need to create a BinarySearchImpl object; Instead we tell Spring to get it for us
		//BinarySearchImpl binarySearch = new BinarySearchImpl(new QuickSortAlgorithm()); 
		//Application context
		try(ClassPathXmlApplicationContext applicationContext =
				new ClassPathXmlApplicationContext("applicationContext.xml")) {
			;
				
			System.out.println(XmlPersonDAO.class);
			/*
			 * XmlPersonDAO personDAO = applicationContext.getBean(XmlPersonDAO.class);
			 * System.out.println(personDAO);
			 * System.out.println(personDAO.getXmlJdbcConnection());
			 */
		
	}
}
}
