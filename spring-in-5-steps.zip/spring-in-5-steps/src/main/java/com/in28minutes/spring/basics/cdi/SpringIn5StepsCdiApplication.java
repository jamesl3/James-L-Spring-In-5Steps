package com.in28minutes.spring.basics.cdi;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan
public class SpringIn5StepsCdiApplication {

	
	//What are the beans? In this case, the new instance of QuickSortAlgorithm is the bean
	//What are the dependencies for each bean? In this case, the dependency of BinarySortImpl
	//is the sortAlgorithm
	//Where should Spring search for Beans?
	
	private static Logger LOGGER = LoggerFactory.getLogger(SpringIn5StepsCdiApplication.class);
	
	public static void main(String[] args) {
		//No need to create a BinarySearchImpl object; Instead we tell Spring to get it for us
		//BinarySearchImpl binarySearch = new BinarySearchImpl(new QuickSortAlgorithm()); 
		//Application context
		try (ConfigurableApplicationContext applicationContext = new AnnotationConfigApplicationContext(
				SpringIn5StepsCdiApplication.class)) {
			;
		
		//System.out.println(SomeCdiBusiness.class);
		SomeCdiBusiness business = applicationContext.getBean(SomeCdiBusiness.class);
		
		
		LOGGER.info("{} dao-{}", business, business.getSomeCdiDAO());
		
		
	}
}
}
